# AverageCalc
Average Calculator (only 2 digits)

Copyright © 2025 liamcodezz

# Usage

1. Clone or download the repo
2. Download python from the microsoft store or the website ( https://www.python.org )
3. Run the python code ( go into terminal, cd into the folder where the averagecalc file is , then run "python averagecalc.py"
