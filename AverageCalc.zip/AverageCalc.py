# define variables

first_digit = int(input("First Number: "))
second_digit = int(input("Second Number: "))

# find the average score

average = (first_digit / 2) + (second_digit / 2)

# print the variables 

print("Average: " + str(average))
print(type(average))
print(int(average))